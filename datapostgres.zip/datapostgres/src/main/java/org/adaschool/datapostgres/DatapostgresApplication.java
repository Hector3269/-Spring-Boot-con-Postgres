package org.adaschool.datapostgres;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatapostgresApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatapostgresApplication.class, args);
	}

}
